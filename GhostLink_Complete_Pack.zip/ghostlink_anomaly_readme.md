
# GhostLink — Anomaly-Structured Harness (v2)
Run:
    python tests/run_proof_v2.py
Outputs:
    proof_v2_report.json
    origin_report.json
