GhostLink — Handoff Kit (v1.0) — October 03, 2025

Use this kit to hire a systems dev and get a PoR-green VM without writing code.

Files
- GhostLink_VM_RFP.pdf — what to send to candidates.
- GhostLink_VM_SOW_Contract.pdf — milestone/payment/IP contract.
- Vendor_Eval_Checklist.csv / .pdf — score vendors.
- Outreach_Email.txt — copy/paste to contacts.
- Job_Post.txt — use on platforms.

Next 3 Actions
1) Send RFP + Outreach_Email to 3–5 strong candidates.
2) Score responses with Vendor_Eval_Checklist and select one.
3) Attach SOW_Contract to a fixed-bid agreement and start Week 0.

Reference pack (send to chosen vendor)
- GhostLink_Final_Project.pdf
- GDL_v1_Substrate_Language.pdf
- GDL_v1_VM_Implementors_Checklist.pdf
- gdl_ir_opcodes.json
- gdl_v1_grammar.txt
- gdl_example.gdl
- gdl_example.ir.json
